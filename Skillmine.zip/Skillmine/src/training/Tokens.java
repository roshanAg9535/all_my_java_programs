package training;
public class Tokens {
	public static void main(String[] args) {
	int a = 20;
	boolean b = true ;
	char c = 'a';
	String g = "Roshan";
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(g);
	}

}
