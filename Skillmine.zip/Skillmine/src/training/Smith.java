package training;

public class Smith {

	public static void main(String[] args) {
		Bob b = new Bob();
		System.out.println(b.a);
		System.out.println(b.b);
		

	}

}
class Bob
{
	static int a =10;
	int b =20;
}