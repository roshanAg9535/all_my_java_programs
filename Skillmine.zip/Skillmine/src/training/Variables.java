package training;

public class Variables {
	public static void main(String[] args) {
		int a = 10;
		byte b = 5;
		short c = 36;
		long l = 45;
		float f = 56.2f;
		double d = 20.5;
		String g = "";
		String h = "   ";
		String n = "welcome to skillmine";
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(g);
		System.out.println(h);
		System.out.println(n);
	}

}
