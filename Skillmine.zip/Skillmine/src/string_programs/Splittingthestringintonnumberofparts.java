package string_programs;

import java.util.Scanner;

public class Splittingthestringintonnumberofparts {
	public static void main(String[] args) {
		System.out.println("enter the string a single word.\n");
		String s1;
		Scanner sc = new Scanner(System.in);
	}

}
