package programs.section;

public class PrintingcharfromAtoz {
	public static void main(String[] args) {
		
		for(char ch='A';ch<='Z';ch++)
		{
			System.out.print(" "+ch);
		}
		System.out.println();
		for(char ch ='a';ch<='z';ch++)
		{
			System.out.print(" "+ch);
		}
		
	}
	

}
