package programs.section;

public class Reversewords {
	public static void wordTake()
	{
		int finalres = 0;boolean res =true;
		
		
	}
	public static void main(String[] args) {
		
	}

}
