package programs.section;

import java.util.HashMap;

public class Revrsebyusingthemap {
	public static void main(String[] args) {
		HashMap<Integer,String> s =new HashMap<Integer,String>();
		s.put(1, "String");
		String rev ="";
		for(int i = 1;i<s.size();i++)
		{
			
		}
		System.out.println(rev);
	}

}
