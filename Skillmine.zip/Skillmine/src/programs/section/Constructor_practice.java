package programs.section;

public class Constructor_practice {
	int b ;
	Constructor_practice(int c)
	{
		this.b=c;
		System.out.println(b);
		
	}
	public static void main(String[] args) {
		new Constructor_practice(20);
		
	}

}
