package programs.section;

public class Pattern8 {
	public static void main(String[] args) {
		int n = 9;
		for(int i = 0;i<=n;i++)
		{
			
		}
	}

}
