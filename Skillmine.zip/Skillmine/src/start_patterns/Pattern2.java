package start_patterns;

public class Pattern2 {

	public static void main(String[] args) {
		
		for(int i=1; i<=5; i++) {
			int num = 1;
			for(int j =1; j<=5; j++) {
					System.out.print(num);
					num++;
			}
			System.out.println();
			
		}

	}

}
