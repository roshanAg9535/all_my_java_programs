package practice;

public class Calculatethesumoffirst10naturalnumber {
	public static void main(String[] args) {
		int num =0;
		
		for(int i =1;i<=10;i++)
		{
			System.out.print(i+num+" ");
			num++;
			
		}
		
	}

}
