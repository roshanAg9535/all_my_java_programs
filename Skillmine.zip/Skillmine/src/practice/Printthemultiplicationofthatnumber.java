package practice;

import java.util.Scanner;

public class Printthemultiplicationofthatnumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int n =sc.nextInt();
		if(n>=0)
		{
		for(int i =1;i<=10;i++)
		{
			System.out.print(n*i+" ");
		}
		}
		else
		{
			System.out.println("Please enter a positive number");
		}
	}
	

}
