package practice;

import java.util.Scanner;

public class Hcf {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number and second number");
		int f1 = sc.nextInt();
		System.out.println("Enter the second number");
		int f2 = sc.nextInt();
		for(int i= 1; i>=f1&&i<=f2;i++)
		{
			
		}
	}

}
