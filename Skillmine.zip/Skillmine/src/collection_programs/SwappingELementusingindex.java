package collection_programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SwappingELementusingindex {
	public static void main(String[] args) {
		List<String>s= new ArrayList<String>();
		s.add("Red");
		s.add("Blue");
		s.add("White");
		s.add("Green");
		System.out.println(s);
		Collections.swap(s, 0, 1);
		System.out.println(s);
		
	}

}
