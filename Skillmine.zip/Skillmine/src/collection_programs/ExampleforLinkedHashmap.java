package collection_programs;

import java.util.HashMap;

public class ExampleforLinkedHashmap {
	public static void main(String[] args) {
		HashMap<String,Integer> a = new HashMap<String,Integer>(); 
		a.put("Mom", 12345);
		a.put("Dad", 5678);
		a.put("Gf", null);
		System.out.println(a);

	
	}

}
