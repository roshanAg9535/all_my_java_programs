package collection_programs;
//it will allow duplicate 
//it will maintain inseration order , so we can fetch it by using index   
//when we enter the new array element it will increase 50%
import java.util.ArrayList;

public class Exampleforarraylist {
	public static void main(String[] args) {
	/*	ArrayList a = new ArrayList(); 
		a.add(10);    
		a.add(10);
		a.add(23.6);
		a.add('e');
		a.add("Roshan");
		a.add(null);
		a.add("Kumar");
		System.out.println(a);*/
		ArrayList<Integer>b=new ArrayList<Integer>();
		b.add(10);    
		b.add(10);
		b.add(23);
		b.add(50);
		b.add(40);
		b.add(2);
		b.add(60);
	//	System.out.println(b);
		for(int a1:b)
		{
			System.out.println(a1);
		}
		
	
	}

}
