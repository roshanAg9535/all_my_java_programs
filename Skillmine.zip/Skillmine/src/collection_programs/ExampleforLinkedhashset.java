package collection_programs;

import java.util.LinkedHashSet;

public class ExampleforLinkedhashset {
	public static void main(String[] args) {
		LinkedHashSet a = new LinkedHashSet	(); 
		a.add(10);    
		a.add(10);
		a.add(23);
		a.add(10);
		a.add(30);
		a.add(50);
		a.add(30);
		System.out.println(a);

	
	}

}
