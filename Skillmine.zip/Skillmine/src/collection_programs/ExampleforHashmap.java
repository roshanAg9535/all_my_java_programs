package collection_programs;

import java.util.LinkedHashMap;

public class ExampleforHashmap {
	public static void main(String[] args) {
		LinkedHashMap<String,Integer> a = new LinkedHashMap<String,Integer>(); 
		a.put("Mom", 12345);
		a.put("Dad", 5678);
		a.put("Gf", null);
		System.out.println(a);

	
	}

}
