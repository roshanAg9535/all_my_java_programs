package collection_programs;

import java.util.TreeSet;

public class ExampleforTreeset {
	public static void main(String[] args) {
		TreeSet a = new TreeSet(); 
		a.add(10);    
		a.add(10);
		a.add(23);
		a.add(10);
		a.add(30);
		a.add(50);
		a.add(30);
		System.out.println(a);

	
	}

}
