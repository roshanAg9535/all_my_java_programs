package collection_programs;
import java.util.HashSet;

public class ExampleforHashset {
	public static void main(String[] args) {
		HashSet a = new HashSet	(); 
		a.add(10);    
		a.add(10);
		a.add(23);
		a.add(10);
		a.add(30);
		a.add(50);
		a.add(30);
		System.out.println(a);

	
	}

}
